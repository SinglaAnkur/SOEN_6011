/**
 * Comparison class contains my_comparison method.
 * It calculates the value of input x based on the Taylor Series expansion of e^x.
 * e^x = 1 + x/1! + x^2/2! + x^3/3! + ......
 * e^x = 1 + (x/1) (1 + (x/2) (1 + (x/3) (........) ) )
 */
public class Comparison
{
    /**
     * @param x Input value of x.
     * @return value of sinh(x).
     * The function is able to calculate for values of x ranging between -700 to 700
     * For x > 15, sinh(x) ≈ (e^x)/2
     * For x < -15, sinh(x) ≈ -((e^(-x))/2
     */
    public static double my_comparison(double x)
    {
        double value_positive_ex = 0;
        double value_negative_ex = 0;
        double output = 0;
        double abs_x = x;
        if(x == 0)
        {
            return 0;
        }
        else if (x > 700 || x < -700)
        {
            System.out.print("Limit exceeds for value of x= ");
            return x;
        }
        else if (x < 0)
        {
            abs_x = x * (-1);
        }
        if ((abs_x > 0 && abs_x <= 15))
        {
            for(int n = 2; n <= 1000; n++)
            {
                value_positive_ex = Validator.exponential(n, abs_x);
                value_negative_ex = Validator.exponential(n, -abs_x);
            }
            output = (value_positive_ex-value_negative_ex)/2;

        }
        else if (abs_x > 15 && abs_x <= 700)
        {
            for(int n = 2; n <= 1000; n++)
            {
                value_positive_ex = Validator.exponential(n, abs_x);
            }
            output = value_positive_ex/2;
        }
        if (x < 0)
        {
            return output*(-1);
        }
        return output;
    }
}
