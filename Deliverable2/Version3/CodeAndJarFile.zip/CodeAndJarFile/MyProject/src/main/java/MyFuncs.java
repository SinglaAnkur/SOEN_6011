/**
 * MyFuncs class contains the helping functions to calculate sinh(x).
 */
class MyFuncs
{
    /**
     * @param s Input value of x.
     * This function calculates the length of input.
     * @return length of the input.
     */
    public static int strLen(String s)
    {
        int len = 0;
        int i = 0;
        s=s+'\0';
        while(s.charAt(i) != '\0')
        {
            len++;
            i++;
        }
        return len;
    }

    /**
     * @param n,x n refers to nth term
     *            x is the Input value of x.
     * This function calculates sum of first n terms in Taylor Series expansion.
     * @return sum.
     */
    public static double exponential(int n, double x)
    {
        double sum = 1;
        for (int i = n - 1; i > 0; --i )
        {
            sum = 1 + x * sum / i;
        }
        return sum;

    }
}